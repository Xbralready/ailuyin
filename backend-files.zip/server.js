const express = require('express');
const cors = require('cors');
const multer = require('multer');
const OpenAI = require('openai');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// 配置OpenAI
let openai = null;
if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });
  console.log('OpenAI API已配置');
} else {
  console.warn('警告: 未配置OPENAI_API_KEY，Whisper转录功能将不可用');
}

// 中间件
app.use(cors({
  origin: function(origin, callback) {
    const allowedOrigins = [
      'http://localhost:5173',
      'http://localhost:3000', 
      'http://127.0.0.1:5173'
    ];
    // 允许没有origin的请求（比如Postman）
    if (!origin || allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  optionsSuccessStatus: 200
}));
app.use(express.json());

// 配置文件上传
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    // 保留原始文件扩展名
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    const ext = path.extname(file.originalname)
    cb(null, file.fieldname + '-' + uniqueSuffix + ext)
  }
})

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 25 * 1024 * 1024, // 25MB限制
  }
});

// 确保uploads目录存在
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

// 音频转文字接口
app.post('/api/transcribe', upload.single('audio'), async (req, res) => {
  try {
    if (!openai) {
      return res.status(503).json({ 
        error: 'Whisper API未配置',
        message: '请配置OPENAI_API_KEY环境变量' 
      });
    }

    if (!req.file) {
      return res.status(400).json({ error: '没有上传音频文件' });
    }

    console.log('收到音频文件:', req.file);

    // 使用Whisper API转录音频
    console.log('开始转录音频，文件路径:', req.file.path);
    console.log('文件大小:', req.file.size, 'bytes');
    
    const transcription = await openai.audio.transcriptions.create({
      file: fs.createReadStream(req.file.path),
      model: 'whisper-1',
      language: 'zh', // 指定中文
      response_format: 'text',
    });
    
    console.log('转录成功，文本长度:', transcription.length);

    // 删除临时文件
    fs.unlinkSync(req.file.path);

    res.json({ 
      success: true,
      text: transcription,
    });
  } catch (error) {
    console.error('转录错误详情:', {
      error: error.message,
      response: error.response?.data,
      status: error.response?.status,
      stack: error.stack
    });
    
    // 清理临时文件
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }

    res.status(500).json({ 
      error: '转录失败',
      message: error.message,
      details: error.response?.data?.error?.message || error.message
    });
  }
});

// ChatGPT分析接口
app.post('/api/analyze', async (req, res) => {
  try {
    console.log('收到分析请求:', { 
      hasTranscript: !!req.body.transcript,
      transcriptLength: req.body.transcript?.length,
      model: req.body.model,
      analysisType: req.body.analysisType 
    });

    if (!openai) {
      return res.status(503).json({ 
        error: 'ChatGPT API未配置',
        message: '请配置OPENAI_API_KEY环境变量' 
      });
    }

    const { transcript, prompt, model, analysisType } = req.body;

    if (!transcript) {
      return res.status(400).json({ error: '没有提供转录文本' });
    }

    const defaultPrompt = `请作为一个智能助手，仔细阅读并分析以下音频转录内容，根据内容的实际类型和场景提供相应的分析：

${transcript}

请根据内容类型提供合适的分析。如果是：
- 客户对话：分析需求、关键信息、后续行动建议
- 财务报告：提取财务指标、业绩亮点、风险与机会
- 会议记录：整理要点、决议、行动计划
- 演讲/陈述：总结核心观点、论据、关键信息
- 其他类型：提供内容摘要、重点分析、洞察发现

请确保分析准确、客观，并使用清晰的结构化格式呈现。`;

    // 使用请求中的模型，如果没有则使用环境变量，最后使用默认值
    const selectedModel = model || process.env.OPENAI_MODEL || 'gpt-3.5-turbo';
    
    const completion = await openai.chat.completions.create({
      model: selectedModel,
      messages: [
        {
          role: 'system',
          content: '你是一个专业的对话分析助手，帮助分析客户与客服之间的对话内容。'
        },
        {
          role: 'user',
          content: prompt || defaultPrompt
        }
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });

    res.json({
      success: true,
      analysis: completion.choices[0].message.content,
    });
  } catch (error) {
    console.error('分析错误详情:', {
      error: error.message,
      stack: error.stack,
      response: error.response?.data
    });
    res.status(500).json({ 
      error: '分析失败',
      message: error.message,
      details: error.response?.data?.error?.message || error.message
    });
  }
});

// 健康检查
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok',
    hasApiKey: !!process.env.OPENAI_API_KEY
  });
});

// 获取可用模型列表
app.get('/api/models', (req, res) => {
  const models = [
    { 
      id: 'gpt-3.5-turbo', 
      name: 'GPT-3.5 Turbo', 
      description: '快速且经济，适合基础分析',
      cost: '💰'
    },
    { 
      id: 'gpt-4o-mini', 
      name: 'GPT-4o Mini', 
      description: '性价比最高，推荐使用',
      cost: '💰💰',
      recommended: true
    },
    { 
      id: 'gpt-4o', 
      name: 'GPT-4o', 
      description: '最强大的分析能力',
      cost: '💰💰💰'
    }
  ];
  
  res.json({
    models,
    currentModel: process.env.OPENAI_MODEL || 'gpt-4o-mini'
  });
});

app.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
});